-- Whitelisted Steam HEX values
local whitelistedHex = {
    "Your Hex ID",
    -- Add more HEX values here as needed and don't forget to add comma if you are new :)
}

-- Function to check if a player's Steam HEX is whitelisted
function IsPlayerWhitelisted(playerHex)
    for _, hex in ipairs(whitelistedHex) do
        if hex == playerHex then
            return true
        end
    end
    return false
end

-- Event to handle player connections
AddEventHandler("playerConnecting", function(name, setKickReason, deferrals)
    local player = source
    local playerIdentifiers = GetPlayerIdentifiers(player)

    -- Loop through the player identifiers to find the Steam HEX
    for _, identifier in ipairs(playerIdentifiers) do
        if string.find(identifier, "steam:") then
            local playerHex = string.sub(identifier, 7) -- Extract the HEX value without the "steam:" prefix

            if IsPlayerWhitelisted(playerHex) then
                deferrals.done() -- Player is whitelisted, allow them to connect
                return
            else
                deferrals.done("The server is currently not launched. Join our discord to stay updated about the launch event. Gang registrations are free and MCPD recruitments are open. Thank You.") -- Player is not whitelisted, kick them with a message
                return
            end
        end
    end

    -- If the loop finishes without returning, there was no Steam HEX identifier found
    deferrals.done("The server is currently not launched. Join our discord to stay updated about the launch event. Gang registrations are free and MCPD recruitments are open. Thank You.")
end)                
