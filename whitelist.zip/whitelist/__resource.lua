-- Resource Metadata
resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

-- Resource Information
description 'Advanced Fivem Server Whitelist Script'
author 'Vengeance ViPER'
version '1.0'

-- Resource Settings
server_script 'server.lua'