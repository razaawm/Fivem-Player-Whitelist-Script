Fivem-Player-Whitelist-Script


Advanced Version of fivem server whitelist system

How to allow players?

Simply go to server.lua. In there go to Line :3 and add your steam hex... Add comma if you increase more than one hex id... :)